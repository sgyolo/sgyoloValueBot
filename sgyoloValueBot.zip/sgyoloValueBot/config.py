token = '6000689883:AAEf0S2MNMJaychM2GsbiLy9BlJWQFUchfk'
help_message = "Этот бот поможет вам узнать курс валют.\nНапишите: <переводимая валюта> <нужная валюта> <кол-во>"
