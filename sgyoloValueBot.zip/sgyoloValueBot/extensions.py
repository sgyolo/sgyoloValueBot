import requests
from json import loads

REQUEST_LINK = "https://www.cbr-xml-daily.ru/latest.js"


class APIException(Exception):
    def __init__(self, text):
        self.text = text


class ValueAPI:
    @staticmethod
    def get_values():
        values = loads(requests.get(REQUEST_LINK).content)
        values["rates"][values["base"]] = 1
        return values["rates"]

    @staticmethod
    def get_price(base: str, quote: str, amount: int | float):
        values = ValueAPI.get_values()

        try:
            amount = float(amount)
        except ValueError:
            raise APIException("Требуется число")

        if base not in values or quote not in values:
            raise APIException("Неподдерживаемый код валюты")

        base = values[base]
        quote = values[quote]

        return round((amount / base) * quote, 2)
