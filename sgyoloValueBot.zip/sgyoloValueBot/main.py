import telebot
from telebot.types import Message

from extensions import ValueAPI, APIException

import config

bot = telebot.TeleBot(config.token)


@bot.message_handler(commands=["start", "help"])
def help_handler(message: Message):
    bot.reply_to(message, config.help_message)


@bot.message_handler(commands=["values"])
def values_handler(message: Message):
    text = "Доступные валюты:\n\n" + ", ".join(ValueAPI.get_values().keys())
    bot.reply_to(message, text)


@bot.message_handler(regexp=r"[a-zA-Z]* [a-zA-Z]* [0-9\.]*")
def exchange_handler(message: Message):
    args = [arg.upper() for arg in message.text.split()]
    try:

        base = args[0]
        query = args[1]
        value = args[2]

        query_value = ValueAPI.get_price(base, query, value)
        bot.reply_to(message, f"{value} {base} ≈ {query_value} {query}")
    except APIException as e:
        bot.reply_to(message, f"Ошибка с API:\n\n{e.text}")
        return
    except Exception as e:
        print("Ошибка:", e)
        bot.reply_to(message, f"Ошибка: {type(e)}")
        return


bot.infinity_polling()
